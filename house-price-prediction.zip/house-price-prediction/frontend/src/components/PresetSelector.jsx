import React from 'react';
import { Sparkles } from 'lucide-react';

export default function PresetSelector({ presets, onSelectPreset }) {
  if (!presets || presets.length === 0) return null;

  return (
    <div className="presets-container">
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
        <Sparkles size={14} color="var(--primary)" />
        <span>Quick Test Presets (One-Click Auto-Fill):</span>
      </div>
      <div className="preset-pills">
        {presets.map((p, idx) => (
          <button
            key={idx}
            type="button"
            className="preset-pill"
            onClick={() => onSelectPreset(p.data)}
            title={p.description}
          >
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}
