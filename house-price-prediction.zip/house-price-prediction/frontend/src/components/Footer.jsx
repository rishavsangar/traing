import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div>
          <strong>House Price Prediction Machine Learning System</strong> — Summer Training Data Science Project
        </div>
        <div>
          Python ML • FastAPI • Scikit-Learn • XGBoost • React Vite
        </div>
      </div>
    </footer>
  );
}
