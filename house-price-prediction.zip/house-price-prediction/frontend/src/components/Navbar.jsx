import React from 'react';
import { Home, BarChart2, Cpu, History, Info, Activity } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, apiStatus }) {
  const navItems = [
    { id: 'predict', label: 'Predictor', icon: <Home size={18} /> },
    { id: 'analytics', label: 'Dataset Analytics', icon: <BarChart2 size={18} /> },
    { id: 'models', label: 'Model Comparison', icon: <Cpu size={18} /> },
    { id: 'history', label: 'History', icon: <History size={18} /> },
    { id: 'about', label: 'Project Docs', icon: <Info size={18} /> }
  ];

  return (
    <header className="navbar">
      <div className="nav-inner">
        <div className="nav-brand" onClick={() => setActiveTab('predict')}>
          <div className="brand-icon">
            <Home size={22} />
          </div>
          <div className="brand-text">
            <h1>PropValuate AI</h1>
            <span className="brand-tag">ML House Price Valuation</span>
          </div>
        </div>

        <nav>
          <ul className="nav-links">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  className={`nav-link ${activeTab === item.id ? 'active' : ''}`}
                  onClick={() => setActiveTab(item.id)}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="api-badge" title="FastAPI Backend Health">
          <span className="status-dot"></span>
          <span>FastAPI {apiStatus ? 'Online' : 'Ready'}</span>
        </div>
      </div>
    </header>
  );
}
