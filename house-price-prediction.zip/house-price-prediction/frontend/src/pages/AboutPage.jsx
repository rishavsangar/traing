import React from 'react';
import { BookOpen, CheckCircle, Code, Layers, FileText, Cpu, Database } from 'lucide-react';

export default function AboutPage() {
  return (
    <div>
      <div className="page-header">
        <h2>📖 Project Documentation & Architecture</h2>
        <p className="page-subtitle">
          BCA / MCA / B.Tech Data Science Summer Training Project: "House Price Prediction Using Machine Learning"
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem', alignItems: 'start' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Executive Overview */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <BookOpen size={20} color="var(--primary)" />
                Executive Project Overview
              </h3>
            </div>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: '1rem' }}>
              Real estate valuation has traditionally relied on subjective manual appraisals, leading to price opacity and market friction. This project engineers a complete, production-grade <strong>Machine Learning regression pipeline</strong> trained on 12,000+ realistic Indian residential property records across 13 major metropolitan markets.
            </p>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              Unlike basic toy scripts, this system implements rigorous data cleaning, IQR outlier handling, multi-factor feature engineering, non-leaking preprocessing pipelines (<code>ColumnTransformer</code>), systematic model benchmarking (Linear Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost), hyperparameter tuning, model serialization via Joblib, and a production FastAPI REST backend integrated with a modern React SPA.
            </p>
          </div>

          {/* Complete Data Science Lifecycle */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Layers size={20} color="var(--primary)" />
                End-to-End Data Science Workflow
              </h3>
            </div>
            <div style={{
              backgroundColor: 'var(--bg-subtle)',
              padding: '1.25rem',
              borderRadius: '8px',
              fontFamily: 'monospace',
              fontSize: '0.85rem',
              lineHeight: 1.6,
              color: 'var(--text-primary)'
            }}>
              Dataset Generation (12,000+ Records) → Data Understanding → Missing Value Imputation (Median / Mode) → Duplicate Removal → Outlier Handling (IQR) → Exploratory Data Analysis (EDA) → Feature Engineering (Total Rooms, Amenity & Distance Scores) → One-Hot & Scaling Pipelines (ColumnTransformer) → 80/20 Train-Test Split → Multi-Model Benchmarking → Hyperparameter Tuning (RandomizedSearchCV) → Model Serialization (Joblib) → FastAPI Prediction Engine → React Frontend UI
            </div>
          </div>

          {/* Academic Summer Training Chapters */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FileText size={20} color="var(--primary)" />
                Summer Training Report Documentation (`docs/`)
              </h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
              Full university-standard academic documentation is included in the project repository:
            </p>
            <div className="form-grid" style={{ fontSize: '0.8125rem' }}>
              <div>• <code>docs/abstract.md</code></div>
              <div>• <code>docs/introduction.md</code></div>
              <div>• <code>docs/problem-statement.md</code></div>
              <div>• <code>docs/objectives.md</code></div>
              <div>• <code>docs/literature-review.md</code></div>
              <div>• <code>docs/methodology.md</code></div>
              <div>• <code>docs/system-requirements.md</code></div>
              <div>• <code>docs/data-preprocessing.md</code></div>
              <div>• <code>docs/eda.md</code></div>
              <div>• <code>docs/machine-learning-models.md</code></div>
              <div>• <code>docs/results.md</code></div>
              <div>• <code>docs/conclusion.md</code></div>
              <div>• <code>docs/future-scope.md</code></div>
              <div>• <code>README.md</code></div>
            </div>
          </div>
        </div>

        {/* Tech Stack Sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="card">
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Code size={20} color="var(--primary)" />
                Technology Stack
              </h3>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <strong style={{ fontSize: '0.85rem', color: 'var(--primary)' }}>Machine Learning:</strong>
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                  Python, Scikit-learn, XGBoost, Pandas, NumPy, Joblib, Seaborn, Matplotlib
                </div>
              </div>

              <div>
                <strong style={{ fontSize: '0.85rem', color: 'var(--primary)' }}>Backend API:</strong>
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                  FastAPI, Pydantic v2, SQLAlchemy ORM, SQLite, Uvicorn
                </div>
              </div>

              <div>
                <strong style={{ fontSize: '0.85rem', color: 'var(--primary)' }}>Frontend Client:</strong>
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                  React 18, Vite, Recharts, Axios, Lucide Icons, Vanilla CSS
                </div>
              </div>

              <div>
                <strong style={{ fontSize: '0.85rem', color: 'var(--primary)' }}>Interactive Notebook:</strong>
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                  Jupyter Notebook (18-step full EDA & modeling walkthrough)
                </div>
              </div>
            </div>
          </div>

          <div className="card" style={{ backgroundColor: 'var(--primary-subtle)', borderColor: 'var(--primary-border)' }}>
            <h4 style={{ fontSize: '0.95rem', color: 'var(--primary)', marginBottom: '0.5rem' }}>
              🎯 Key Academic Deliverables
            </h4>
            <ul style={{ fontSize: '0.8125rem', color: 'var(--text-primary)', paddingLeft: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.375rem' }}>
              <li>10,000+ realistic Indian property dataset</li>
              <li>Preprocessed without data leakage</li>
              <li>5 Regression algorithms evaluated</li>
              <li>Hyperparameter tuning via cross-validation</li>
              <li>Swagger REST documentation at <code>/docs</code></li>
              <li>Production responsive React user interface</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
