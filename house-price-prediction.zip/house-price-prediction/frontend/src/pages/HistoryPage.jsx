import React, { useState, useEffect } from 'react';
import { History, Trash2, RefreshCw, Clock, Building } from 'lucide-react';
import { apiService } from '../services/api';

function formatIndianNumber(num) {
  if (!num) return '0';
  const s = Math.round(num).toString();
  if (s.length <= 3) return s;
  const lastThree = s.substring(s.length - 3);
  const otherNumbers = s.substring(0, s.length - 3);
  return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + lastThree;
}

function formatLakhsCrores(num) {
  if (!num) return '₹0';
  if (num >= 10000000) {
    return `₹${(num / 10000000).toFixed(2)} Cr`;
  }
  if (num >= 100000) {
    return `₹${(num / 100000).toFixed(2)} Lakhs`;
  }
  return `₹${formatIndianNumber(num)}`;
}

export default function HistoryPage() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchHistory = () => {
    setLoading(true);
    apiService.getPredictionHistory()
      .then((data) => {
        setHistory(data || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to fetch prediction logs:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleClearHistory = async () => {
    if (window.confirm('Are you sure you want to clear all prediction history?')) {
      try {
        await apiService.clearPredictionHistory();
        setHistory([]);
      } catch (err) {
        console.error('Failed to clear history:', err);
      }
    }
  };

  return (
    <div>
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2>📜 Prediction History Log</h2>
          <p className="page-subtitle">
            Auditable log of past property valuations recorded in the SQLite database.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button className="btn-secondary" onClick={fetchHistory} disabled={loading} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
            <RefreshCw size={15} /> Refresh
          </button>
          {history.length > 0 && (
            <button className="btn-secondary" onClick={handleClearHistory} style={{ color: 'var(--danger)', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
              <Trash2 size={15} /> Clear History
            </button>
          )}
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div style={{ textAlign: 'center', padding: '3rem 0', color: 'var(--text-muted)' }}>
            Loading prediction logs...
          </div>
        ) : history.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3.5rem 1.5rem', color: 'var(--text-muted)' }}>
            <Clock size={40} style={{ margin: '0 auto 0.75rem auto', color: 'var(--text-muted)' }} />
            <h3 style={{ fontSize: '1.1rem', color: 'var(--text-primary)', marginBottom: '0.25rem' }}>
              No Predictions Logged Yet
            </h3>
            <p style={{ fontSize: '0.875rem' }}>
              Go to the <strong>Predictor</strong> tab and submit a property to see it recorded here.
            </p>
          </div>
        ) : (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Location</th>
                  <th>Specs (BHK / Area)</th>
                  <th>Property Type</th>
                  <th>Predicted Price</th>
                  <th>Estimated Confidence Range</th>
                  <th>Model Used</th>
                </tr>
              </thead>
              <tbody>
                {history.map((item) => (
                  <tr key={item.id}>
                    <td style={{ fontSize: '0.775rem', color: 'var(--text-muted)' }}>
                      {new Date(item.created_at).toLocaleString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                    <td><strong>{item.location}</strong></td>
                    <td>{item.bedrooms} BHK • {item.area_sqft} sq.ft</td>
                    <td>{item.property_type || 'Apartment'}</td>
                    <td style={{ color: 'var(--primary)', fontWeight: 700 }}>
                      {formatLakhsCrores(item.predicted_price)}
                    </td>
                    <td style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                      {formatLakhsCrores(item.estimated_low)} – {formatLakhsCrores(item.estimated_high)}
                    </td>
                    <td>
                      <span style={{ fontSize: '0.75rem', backgroundColor: 'var(--bg-subtle)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>
                        {item.model_name || 'ML Model'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
