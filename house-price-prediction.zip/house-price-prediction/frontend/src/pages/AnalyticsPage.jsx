import React, { useState, useEffect } from 'react';
import { Database, TrendingUp, IndianRupee, MapPin, Award, Layers } from 'lucide-react';
import { apiService } from '../services/api';
import StatCard from '../components/StatCard';
import PriceDistributionChart from '../charts/PriceDistributionChart';
import LocationPriceChart from '../charts/LocationPriceChart';
import AreaPriceScatterChart from '../charts/AreaPriceScatterChart';
import BedroomPriceChart from '../charts/BedroomPriceChart';

function formatIndianNumber(num) {
  if (!num) return '0';
  const s = Math.round(num).toString();
  if (s.length <= 3) return s;
  const lastThree = s.substring(s.length - 3);
  const otherNumbers = s.substring(0, s.length - 3);
  return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + lastThree;
}

function formatLakhsCrores(num) {
  if (!num) return '₹0';
  if (num >= 10000000) {
    return `₹${(num / 10000000).toFixed(2)} Cr`;
  }
  if (num >= 100000) {
    return `₹${(num / 100000).toFixed(2)} Lakhs`;
  }
  return `₹${formatIndianNumber(num)}`;
}

export default function AnalyticsPage() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiService.getAnalytics()
      .then((data) => {
        setAnalytics(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load analytics:', err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--text-muted)' }}>
        Loading dataset analytics and distributions...
      </div>
    );
  }

  if (!analytics) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--danger)' }}>
        Failed to load analytics. Please check backend connection.
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <h2>📊 Dataset Exploratory Data Analysis (EDA)</h2>
        <p className="page-subtitle">
          Real-time analytics and distributions calculated across {analytics.total_properties?.toLocaleString()} historical property records.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <StatCard
          title="Total Properties Analyzed"
          value={analytics.total_properties?.toLocaleString() || '12,500'}
          subtitle="Cleaned historical dataset"
          icon={<Database size={22} />}
        />

        <StatCard
          title="Average House Price"
          value={formatLakhsCrores(analytics.average_price)}
          subtitle={`₹${formatIndianNumber(analytics.average_price)}`}
          icon={<TrendingUp size={22} />}
        />

        <StatCard
          title="Median House Price"
          value={formatLakhsCrores(analytics.median_price)}
          subtitle={`₹${formatIndianNumber(analytics.median_price)}`}
          icon={<IndianRupee size={22} />}
        />

        <StatCard
          title="Avg Price / Sq.Ft"
          value={`₹${Math.round(analytics.average_price_per_sqft || 7500).toLocaleString()}`}
          subtitle="Across all tiers & cities"
          icon={<Layers size={22} />}
        />

        <StatCard
          title="Most Premium Market"
          value={analytics.most_expensive_location || 'Mumbai'}
          subtitle={`Lowest: ${analytics.cheapest_location || 'Jalandhar'}`}
          icon={<MapPin size={22} />}
        />
      </div>

      {/* Charts Grid */}
      <div className="charts-grid">
        {/* Chart 1: Price Distribution */}
        <div className="chart-card">
          <div className="chart-header">
            <h3 className="chart-title">Price Distribution (Histogram)</h3>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Target Variable Spread</span>
          </div>
          <PriceDistributionChart data={analytics.price_distribution} />
        </div>

        {/* Chart 2: Average Price by Location */}
        <div className="chart-card">
          <div className="chart-header">
            <h3 className="chart-title">Average Property Price by City</h3>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Values in ₹ Lakhs</span>
          </div>
          <LocationPriceChart data={analytics.city_analytics} />
        </div>

        {/* Chart 3: Area vs Price */}
        <div className="chart-card">
          <div className="chart-header">
            <h3 className="chart-title">Area (Sq.Ft) vs Selling Price</h3>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Linear & Non-linear Trends</span>
          </div>
          <AreaPriceScatterChart data={analytics.area_vs_price_samples} />
        </div>

        {/* Chart 4: Bedrooms vs Price */}
        <div className="chart-card">
          <div className="chart-header">
            <h3 className="chart-title">Price by Bedroom Configuration (BHK)</h3>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Room Count Impact</span>
          </div>
          <BedroomPriceChart data={analytics.bedroom_distribution} />
        </div>
      </div>

      {/* Detailed City Analytics Table */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">City-Level Price & Market Benchmark</h3>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>13 Indian Real Estate Markets</span>
        </div>
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>City Location</th>
                <th>Properties Tracked</th>
                <th>Average Price</th>
                <th>Median Price</th>
                <th>Avg Rate / Sq.Ft</th>
              </tr>
            </thead>
            <tbody>
              {analytics.city_analytics?.map((c) => (
                <tr key={c.location}>
                  <td><strong>{c.location}</strong></td>
                  <td>{c.count.toLocaleString()}</td>
                  <td>{formatLakhsCrores(c.avg_price)} (₹{formatIndianNumber(c.avg_price)})</td>
                  <td>{formatLakhsCrores(c.median_price)}</td>
                  <td style={{ color: 'var(--primary)', fontWeight: 600 }}>₹{Math.round(c.avg_price_per_sqft).toLocaleString()} / sq.ft</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
