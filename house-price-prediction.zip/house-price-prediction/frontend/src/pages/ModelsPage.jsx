import React, { useState, useEffect } from 'react';
import { Cpu, Award, CheckCircle2, Sliders, Zap, BarChart3 } from 'lucide-react';
import { apiService } from '../services/api';
import StatCard from '../components/StatCard';
import ModelComparisonBarChart from '../charts/ModelComparisonBarChart';

function formatIndianNumber(num) {
  if (!num) return '0';
  const s = Math.round(num).toString();
  if (s.length <= 3) return s;
  const lastThree = s.substring(s.length - 3);
  const otherNumbers = s.substring(0, s.length - 3);
  return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + lastThree;
}

export default function ModelsPage() {
  const [modelData, setModelData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiService.getModelMetrics()
      .then((data) => {
        setModelData(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load model metrics:', err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--text-muted)' }}>
        Loading evaluated ML model comparisons and benchmarks...
      </div>
    );
  }

  if (!modelData) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--danger)' }}>
        Failed to load model evaluation metrics.
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <h2>🤖 Machine Learning Algorithm Comparison & Benchmarks</h2>
        <p className="page-subtitle">
          Side-by-side evaluation metrics derived from real 80/20 train-test splits on {modelData.total_samples?.toLocaleString()} records.
        </p>
      </div>

      {/* Top Best Model Summary Banner */}
      <div className="card" style={{
        background: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)',
        color: '#ffffff',
        marginBottom: '2rem',
        padding: '1.75rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', backgroundColor: 'rgba(255,255,255,0.15)', padding: '0.25rem 0.75rem', borderRadius: '9999px', fontSize: '0.8125rem', fontWeight: 600, marginBottom: '0.5rem' }}>
              <Award size={16} color="#fde047" />
              <span>CHOSEN PRODUCTION MODEL</span>
            </div>
            <h3 style={{ fontSize: '1.5rem', color: '#ffffff', fontWeight: 700 }}>
              {modelData.best_model_name}
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#cbd5e1', marginTop: '0.25rem' }}>
              Tuned using GridSearchCV & RandomizedSearchCV for optimal generalization on Indian real estate data.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
            <div style={{ backgroundColor: 'rgba(255,255,255,0.1)', padding: '0.75rem 1.25rem', borderRadius: '8px', textAlign: 'center' }}>
              <div style={{ fontSize: '0.75rem', color: '#93c5fd', textTransform: 'uppercase' }}>R² Test Score</div>
              <div style={{ fontSize: '1.35rem', fontWeight: 800, color: '#4ade80' }}>
                {(modelData.best_r2_score * 100).toFixed(2)}% ({modelData.best_r2_score})
              </div>
            </div>

            <div style={{ backgroundColor: 'rgba(255,255,255,0.1)', padding: '0.75rem 1.25rem', borderRadius: '8px', textAlign: 'center' }}>
              <div style={{ fontSize: '0.75rem', color: '#93c5fd', textTransform: 'uppercase' }}>Mean Abs % Error (MAPE)</div>
              <div style={{ fontSize: '1.35rem', fontWeight: 800, color: '#fef08a' }}>
                {modelData.best_mape}%
              </div>
            </div>

            <div style={{ backgroundColor: 'rgba(255,255,255,0.1)', padding: '0.75rem 1.25rem', borderRadius: '8px', textAlign: 'center' }}>
              <div style={{ fontSize: '0.75rem', color: '#93c5fd', textTransform: 'uppercase' }}>RMSE</div>
              <div style={{ fontSize: '1.35rem', fontWeight: 800, color: '#ffffff' }}>
                ₹{formatIndianNumber(modelData.best_rmse)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Model Performance Comparison Table */}
      <div className="card" style={{ marginBottom: '2rem' }}>
        <div className="card-header">
          <h3 className="card-title">Comprehensive Model Performance Leaderboard</h3>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Sorted by R² Accuracy</span>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Algorithm Name</th>
                <th>MAE (Mean Absolute Error)</th>
                <th>RMSE (Root Mean Sq. Error)</th>
                <th>R² Score (Accuracy)</th>
                <th>MAPE (Mean % Error)</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {modelData.models?.map((m) => (
                <tr key={m.model_name} className={m.is_best_model ? 'highlight-best' : ''}>
                  <td>
                    <strong>{m.model_name}</strong>
                    {m.is_best_model && (
                      <span className="badge-trophy">
                        <Award size={12} /> Best Model
                      </span>
                    )}
                  </td>
                  <td>₹{formatIndianNumber(m.mae)}</td>
                  <td>₹{formatIndianNumber(m.rmse)}</td>
                  <td>
                    <span style={{
                      fontWeight: 700,
                      color: m.r2 >= 0.88 ? 'var(--success)' : m.r2 >= 0.75 ? 'var(--primary)' : 'var(--warning)'
                    }}>
                      {m.r2.toFixed(4)} ({(m.r2 * 100).toFixed(1)}%)
                    </span>
                  </td>
                  <td>{m.mape.toFixed(2)}%</td>
                  <td>
                    {m.is_best_model ? (
                      <span style={{ color: 'var(--success)', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                        <CheckCircle2 size={15} /> Active in API
                      </span>
                    ) : (
                      <span style={{ color: 'var(--text-muted)' }}>Evaluated</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Accuracy Chart & Feature Importance Grid */}
      <div className="charts-grid">
        {/* Model Accuracy Comparison Bar Chart */}
        <div className="chart-card">
          <div className="chart-header">
            <h3 className="chart-title">R² Accuracy Score Comparison (%)</h3>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Higher is Better</span>
          </div>
          <ModelComparisonBarChart models={modelData.models} />
        </div>

        {/* Feature Importance Ranking */}
        <div className="chart-card">
          <div className="chart-header">
            <h3 className="chart-title">Feature Importance Analysis (Gini / Gain)</h3>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Top Valuation Drivers</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
            {modelData.feature_importances?.slice(0, 7).map((feat, idx) => (
              <div key={idx}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', marginBottom: '0.25rem' }}>
                  <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>
                    {feat.feature.replace('location_', 'City: ').replace('property_type_', 'Type: ')}
                  </span>
                  <span style={{ color: 'var(--primary)', fontWeight: 700 }}>{feat.importance}%</span>
                </div>
                <div style={{ height: '8px', backgroundColor: 'var(--bg-subtle)', borderRadius: '9999px', overflow: 'hidden' }}>
                  <div style={{
                    height: '100%',
                    width: `${Math.min(feat.importance * 2.2, 100)}%`,
                    backgroundColor: idx === 0 ? 'var(--primary)' : idx === 1 ? 'var(--accent)' : '#60a5fa',
                    borderRadius: '9999px'
                  }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Hyperparameter Tuning Card */}
      <div className="card" style={{ marginTop: '2rem' }}>
        <div className="card-header">
          <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Sliders size={20} color="var(--primary)" />
            Hyperparameter Tuning Specifications
          </h3>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Cross-Validation K-Fold = 3</span>
        </div>

        <div className="form-grid-3">
          <div style={{ backgroundColor: 'var(--bg-subtle)', padding: '1rem', borderRadius: '8px' }}>
            <div style={{ fontWeight: 700, fontSize: '0.875rem', marginBottom: '0.5rem', color: 'var(--primary)' }}>
              Random Forest Parameters
            </div>
            <ul style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', paddingLeft: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
              <li><code>n_estimators</code>: [100, 150, 200]</li>
              <li><code>max_depth</code>: [14, 18, 22]</li>
              <li><code>min_samples_split</code>: [2, 4]</li>
              <li><code>min_samples_leaf</code>: [1, 2]</li>
            </ul>
          </div>

          <div style={{ backgroundColor: 'var(--bg-subtle)', padding: '1rem', borderRadius: '8px' }}>
            <div style={{ fontWeight: 700, fontSize: '0.875rem', marginBottom: '0.5rem', color: 'var(--primary)' }}>
              Gradient Boosting Parameters
            </div>
            <ul style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', paddingLeft: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
              <li><code>n_estimators</code>: [120, 180, 220]</li>
              <li><code>learning_rate</code>: [0.05, 0.08, 0.12]</li>
              <li><code>max_depth</code>: [4, 6, 8]</li>
              <li><code>subsample</code>: [0.8, 0.9, 1.0]</li>
            </ul>
          </div>

          <div style={{ backgroundColor: 'var(--bg-subtle)', padding: '1rem', borderRadius: '8px' }}>
            <div style={{ fontWeight: 700, fontSize: '0.875rem', marginBottom: '0.5rem', color: 'var(--primary)' }}>
              XGBoost Parameters
            </div>
            <ul style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', paddingLeft: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
              <li><code>n_estimators</code>: [120, 180, 240]</li>
              <li><code>learning_rate</code>: [0.04, 0.08, 0.12]</li>
              <li><code>max_depth</code>: [5, 6, 8]</li>
              <li><code>colsample_bytree</code>: [0.8, 0.9]</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
