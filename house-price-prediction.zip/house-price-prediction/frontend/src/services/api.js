import axios from 'axios';

const API_BASE = '/api';

const apiClient = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const apiService = {
  async predictPrice(propertyData) {
    const response = await apiClient.post('/predict', propertyData);
    return response.data;
  },

  async getAnalytics() {
    const response = await apiClient.get('/analytics');
    return response.data;
  },

  async getModelMetrics() {
    const response = await apiClient.get('/models');
    return response.data;
  },

  async getPredictionHistory(limit = 50) {
    const response = await apiClient.get(`/predictions/history?limit=${limit}`);
    return response.data;
  },

  async clearPredictionHistory() {
    const response = await apiClient.delete('/predictions/history');
    return response.data;
  },

  async getMetadata() {
    const response = await apiClient.get('/locations');
    return response.data;
  },

  async checkHealth() {
    const response = await apiClient.get('/health');
    return response.data;
  }
};
