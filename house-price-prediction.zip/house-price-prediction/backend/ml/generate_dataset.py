"""
Synthetic & Realistic Indian Housing Dataset Generator
Project: House Price Prediction Using Machine Learning
Generates 10,000+ realistic records across 13 Indian cities with real-world distribution and variance.
"""

import os
import numpy as np
import pandas as pd

# Set seed for reproducibility
np.random.seed(42)

LOCATIONS = [
    "Delhi", "Mumbai", "Bangalore", "Hyderabad", "Chandigarh",
    "Mohali", "Jalandhar", "Ludhiana", "Amritsar", "Pune",
    "Jaipur", "Noida", "Gurgaon"
]

# Base price per sqft (INR) reflecting real Indian market tiers
LOCATION_BASE_PRICE_PER_SQFT = {
    "Mumbai": 22000,
    "Delhi": 12500,
    "Gurgaon": 11500,
    "Bangalore": 9200,
    "Hyderabad": 7800,
    "Pune": 7500,
    "Noida": 7200,
    "Chandigarh": 6800,
    "Mohali": 5200,
    "Jaipur": 4500,
    "Ludhiana": 4100,
    "Amritsar": 3800,
    "Jalandhar": 3600
}

PROPERTY_TYPES = ["Apartment", "Independent House", "Villa", "Builder Floor", "Penthouse"]
PROPERTY_TYPE_WEIGHTS = [0.55, 0.20, 0.10, 0.12, 0.03]

FURNISHING_STATUSES = ["Unfurnished", "Semi-Furnished", "Fully-Furnished"]
FURNISHING_WEIGHTS = [0.35, 0.45, 0.20]

def generate_housing_dataset(n_samples: int = 12000, output_path: str = None) -> pd.DataFrame:
    """
    Generates a realistic housing dataset with Indian real estate economic logic.
    """
    print(f"Generating {n_samples} realistic housing records...")

    locations = np.random.choice(LOCATIONS, size=n_samples)
    property_types = np.random.choice(PROPERTY_TYPES, size=n_samples, p=PROPERTY_TYPE_WEIGHTS)
    furnishings = np.random.choice(FURNISHING_STATUSES, size=n_samples, p=FURNISHING_WEIGHTS)

    # Area in square feet based on property type
    areas = []
    bedrooms = []
    bathrooms = []
    balconies = []
    total_floors_list = []
    floor_list = []

    for ptype in property_types:
        if ptype == "Apartment":
            bhk = np.random.choice([1, 2, 3, 4], p=[0.15, 0.45, 0.32, 0.08])
            area = int(bhk * np.random.uniform(450, 650) + np.random.normal(50, 40))
            baths = min(bhk + np.random.choice([0, 1], p=[0.6, 0.4]), bhk + 1)
            balc = np.random.choice([1, 2, 3], p=[0.4, 0.45, 0.15])
            tot_fl = np.random.randint(4, 32)
            fl = np.random.randint(0, tot_fl)
        elif ptype == "Builder Floor":
            bhk = np.random.choice([2, 3, 4], p=[0.35, 0.50, 0.15])
            area = int(bhk * np.random.uniform(500, 750) + np.random.normal(70, 50))
            baths = bhk
            balc = np.random.choice([1, 2, 3], p=[0.3, 0.5, 0.2])
            tot_fl = 4
            fl = np.random.randint(1, 5)
        elif ptype == "Independent House":
            bhk = np.random.choice([2, 3, 4, 5], p=[0.2, 0.45, 0.25, 0.1])
            area = int(bhk * np.random.uniform(600, 900) + np.random.normal(150, 80))
            baths = bhk
            balc = np.random.choice([1, 2, 3, 4], p=[0.2, 0.4, 0.3, 0.1])
            tot_fl = np.random.choice([1, 2, 3], p=[0.4, 0.45, 0.15])
            fl = 0
        elif ptype == "Villa":
            bhk = np.random.choice([3, 4, 5, 6], p=[0.2, 0.45, 0.25, 0.1])
            area = int(bhk * np.random.uniform(800, 1200) + np.random.normal(300, 100))
            baths = bhk + np.random.choice([0, 1], p=[0.5, 0.5])
            balc = np.random.choice([2, 3, 4], p=[0.3, 0.5, 0.2])
            tot_fl = np.random.choice([2, 3], p=[0.7, 0.3])
            fl = 0
        else: # Penthouse
            bhk = np.random.choice([4, 5, 6], p=[0.4, 0.4, 0.2])
            area = int(bhk * np.random.uniform(900, 1400) + np.random.normal(400, 120))
            baths = bhk + 1
            balc = np.random.choice([3, 4, 5], p=[0.3, 0.5, 0.2])
            tot_fl = np.random.randint(15, 35)
            fl = tot_fl

        areas.append(max(area, 400))
        bedrooms.append(max(int(bhk), 1))
        bathrooms.append(max(int(baths), 1))
        balconies.append(max(int(balc), 0))
        total_floors_list.append(int(tot_fl))
        floor_list.append(int(fl))

    property_ages = np.random.exponential(scale=7, size=n_samples).astype(int)
    property_ages = np.clip(property_ages, 0, 35)

    parkings = np.random.choice([0, 1, 2, 3], size=n_samples, p=[0.20, 0.55, 0.20, 0.05])

    # Distance to facilities in km
    dist_school = np.round(np.random.gamma(shape=2.0, scale=1.2, size=n_samples), 2)
    dist_hospital = np.round(np.random.gamma(shape=2.5, scale=1.5, size=n_samples), 2)
    dist_market = np.round(np.random.gamma(shape=1.8, scale=1.0, size=n_samples), 2)
    dist_metro = np.round(np.random.gamma(shape=3.0, scale=1.8, size=n_samples), 2)

    # Nearby binary flags (within 2 km)
    nearby_school = (dist_school <= 2.0).astype(int)
    nearby_hospital = (dist_hospital <= 2.5).astype(int)
    nearby_market = (dist_market <= 1.5).astype(int)

    # Calculate realistic housing valuation (Target: price in INR)
    prices = []
    for i in range(n_samples):
        loc = locations[i]
        base_rate = LOCATION_BASE_PRICE_PER_SQFT[loc]
        area = areas[i]
        ptype = property_types[i]
        furnish = furnishings[i]
        age = property_ages[i]
        park = parkings[i]
        fl = floor_list[i]
        tot_fl = total_floors_list[i]
        d_metro = dist_metro[i]
        d_hosp = dist_hospital[i]
        d_sch = dist_school[i]
        d_mkt = dist_market[i]

        # Property type multiplier
        type_mult = {
            "Apartment": 1.0,
            "Builder Floor": 1.06,
            "Independent House": 1.18,
            "Villa": 1.35,
            "Penthouse": 1.50
        }[ptype]

        # Furnishing multiplier
        furn_mult = {
            "Unfurnished": 1.0,
            "Semi-Furnished": 1.06,
            "Fully-Furnished": 1.15
        }[furnish]

        # Age depreciation curve
        age_factor = max(0.68, 1.0 - (age * 0.0095))

        # Parking premium
        park_premium = park * (base_rate * 25)

        # Floor premium (middle floors desirable, penthouses top floor)
        if ptype in ["Apartment"]:
            floor_factor = 1.0 + (min(fl, 15) * 0.004)
        else:
            floor_factor = 1.0

        # Metro connectivity bonus (closer to metro is higher value)
        metro_factor = 1.0 + max(0, (5.0 - min(d_metro, 5.0)) * 0.02)

        # Amenities proximity bonus
        amenity_bonus = (
            (max(0, 3.0 - min(d_sch, 3.0)) * 0.01) +
            (max(0, 3.0 - min(d_hosp, 3.0)) * 0.012) +
            (max(0, 2.0 - min(d_mkt, 2.0)) * 0.015)
        )

        # Baseline value calculation
        calculated_price = (
            area * base_rate * type_mult * furn_mult * age_factor * floor_factor * metro_factor * (1.0 + amenity_bonus)
            + park_premium
        )

        # Add realistic market stochastic noise (log-normal noise, std dev ~11%)
        noise = np.random.normal(0, 0.11)
        final_price = calculated_price * np.exp(noise)

        # Round to nearest 10,000 INR
        final_price = round(final_price / 10000) * 10000
        prices.append(max(final_price, 800000))

    df = pd.DataFrame({
        "id": range(1, n_samples + 1),
        "location": locations,
        "area_sqft": areas,
        "bedrooms": bedrooms,
        "bathrooms": bathrooms,
        "property_age": property_ages,
        "parking": parkings,
        "floor": floor_list,
        "total_floors": total_floors_list,
        "furnishing_status": furnishings,
        "balconies": balconies,
        "property_type": property_types,
        "distance_school_km": dist_school,
        "distance_hospital_km": dist_hospital,
        "distance_market_km": dist_market,
        "distance_metro_km": dist_metro,
        "nearby_school": nearby_school,
        "nearby_hospital": nearby_hospital,
        "nearby_market": nearby_market,
        "price": prices
    })

    # Add a small number of realistic missing values for preprocessing demonstration (<0.5%)
    mask_missing = np.random.rand(len(df)) < 0.005
    df.loc[mask_missing & (df.index % 2 == 0), "distance_metro_km"] = np.nan
    df.loc[mask_missing & (df.index % 3 == 0), "furnishing_status"] = np.nan

    # Add a tiny number of duplicate rows (<0.3%)
    n_dups = int(n_samples * 0.003)
    dup_rows = df.sample(n=n_dups, random_state=42)
    df = pd.concat([df, dup_rows], ignore_index=True)

    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        df.to_csv(output_path, index=False)
        print(f"Dataset successfully saved to: {output_path} ({len(df)} total rows)")

    return df

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_csv = os.path.join(current_dir, "..", "data", "raw_house_prices.csv")
    generate_housing_dataset(n_samples=12500, output_path=target_csv)
