"""
Data Preprocessing & Feature Engineering Pipeline
Project: House Price Prediction Using Machine Learning
Handles data cleaning, outlier removal (IQR), missing value imputation,
feature engineering, and Scikit-Learn ColumnTransformer pipeline creation.
"""

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

# Numerical and Categorical feature definitions
RAW_NUMERICAL_COLS = [
    "area_sqft", "bedrooms", "bathrooms", "property_age", "parking",
    "floor", "total_floors", "balconies",
    "distance_school_km", "distance_hospital_km", "distance_market_km", "distance_metro_km",
    "nearby_school", "nearby_hospital", "nearby_market"
]

RAW_CATEGORICAL_COLS = [
    "location", "property_type", "furnishing_status"
]

ENGINEERED_NUMERICAL_COLS = [
    "total_rooms", "amenity_score", "distance_score", "floor_ratio"
]

ENGINEERED_CATEGORICAL_COLS = [
    "property_age_group"
]

ALL_NUMERICAL_FEATURES = RAW_NUMERICAL_COLS + ENGINEERED_NUMERICAL_COLS
ALL_CATEGORICAL_FEATURES = RAW_CATEGORICAL_COLS + ENGINEERED_CATEGORICAL_COLS

def clean_raw_data(df: pd.DataFrame, is_training: bool = True) -> pd.DataFrame:
    """
    Cleans raw dataframe: removes duplicates, checks valid ranges,
    and removes extreme outliers for training.
    """
    data = df.copy()

    # 1. Drop duplicates
    if is_training:
        feature_subset = [c for c in RAW_NUMERICAL_COLS + RAW_CATEGORICAL_COLS if c in data.columns]
        data = data.drop_duplicates(subset=feature_subset).reset_index(drop=True)

    # 2. Filter invalid values
    if "area_sqft" in data.columns:
        data = data[data["area_sqft"] > 0]
    if "bedrooms" in data.columns:
        data = data[data["bedrooms"] > 0]
    if "bathrooms" in data.columns:
        data = data[data["bathrooms"] > 0]
    if "property_age" in data.columns:
        data = data[data["property_age"] >= 0]
    if "price" in data.columns and is_training:
        data = data[data["price"] > 0]

    # 3. Outlier removal using IQR on training price & area
    if is_training and "price" in data.columns:
        # Price IQR filtering
        q1_p = data["price"].quantile(0.01)
        q3_p = data["price"].quantile(0.99)
        data = data[(data["price"] >= q1_p) & (data["price"] <= q3_p)]

        # Area IQR filtering
        q1_a = data["area_sqft"].quantile(0.01)
        q3_a = data["area_sqft"].quantile(0.99)
        data = data[(data["area_sqft"] >= q1_a) & (data["area_sqft"] <= q3_a)]

    return data.reset_index(drop=True)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Computes derived domain-specific features without target leakage.
    """
    data = df.copy()

    # 1. Total rooms
    bedrooms = data["bedrooms"].fillna(2)
    bathrooms = data["bathrooms"].fillna(2)
    balconies = data["balconies"].fillna(1)
    data["total_rooms"] = bedrooms + bathrooms + balconies

    # 2. Amenity score (0 to 3)
    n_sch = data["nearby_school"].fillna(0)
    n_hosp = data["nearby_hospital"].fillna(0)
    n_mkt = data["nearby_market"].fillna(0)
    data["amenity_score"] = n_sch + n_hosp + n_mkt

    # 3. Distance score (inverse distance sum - higher is better)
    d_sch = data["distance_school_km"].fillna(2.0)
    d_hosp = data["distance_hospital_km"].fillna(2.5)
    d_mkt = data["distance_market_km"].fillna(1.5)
    d_metro = data["distance_metro_km"].fillna(3.0)

    data["distance_score"] = (
        (1.0 / (1.0 + d_sch)) +
        (1.0 / (1.0 + d_hosp)) +
        (1.0 / (1.0 + d_mkt)) +
        (1.0 / (1.0 + d_metro))
    )

    # 4. Property age group (binned)
    ages = data["property_age"].fillna(5)
    data["property_age_group"] = pd.cut(
        ages,
        bins=[-1, 3, 10, 100],
        labels=["New (0-3 yrs)", "Moderate (4-10 yrs)", "Old (10+ yrs)"]
    ).astype(str)

    # 5. Floor ratio
    fl = data["floor"].fillna(1)
    tot_fl = np.maximum(data["total_floors"].fillna(4), 1)
    data["floor_ratio"] = (fl / tot_fl).clip(0.0, 1.0)

    return data


def build_column_transformer() -> ColumnTransformer:
    """
    Builds the Scikit-Learn ColumnTransformer for scaling numericals
    and one-hot encoding categoricals.
    """
    num_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    cat_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", num_pipeline, ALL_NUMERICAL_FEATURES),
            ("cat", cat_pipeline, ALL_CATEGORICAL_FEATURES)
        ],
        remainder="drop"
    )

    return preprocessor


def prepare_data_for_training(raw_df: pd.DataFrame):
    """
    Executes full preprocessing: cleaning, feature engineering,
    and returns X, y ready for train_test_split.
    """
    cleaned_df = clean_raw_data(raw_df, is_training=True)
    engineered_df = engineer_features(cleaned_df)

    feature_cols = ALL_NUMERICAL_FEATURES + ALL_CATEGORICAL_FEATURES
    X = engineered_df[feature_cols]
    y = engineered_df["price"]

    return X, y, cleaned_df
