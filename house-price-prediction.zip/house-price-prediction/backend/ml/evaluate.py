"""
Model Evaluation & Metrics Calculation
Project: House Price Prediction Using Machine Learning
Evaluates models using MAE, MSE, RMSE, R² Score, and MAPE.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    mean_absolute_percentage_error
)

def evaluate_model(y_true, y_pred, model_name: str = "Model") -> dict:
    """
    Computes comprehensive evaluation metrics for regression predictions.
    """
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    mape = mean_absolute_percentage_error(y_true, y_pred) * 100 # In percentage

    return {
        "model_name": model_name,
        "mae": round(float(mae), 2),
        "mse": round(float(mse), 2),
        "rmse": round(float(rmse), 2),
        "r2": round(float(r2), 4),
        "mape": round(float(mape), 2)
    }

def print_evaluation_summary(results: list):
    """
    Prints a formatted markdown-like ASCII table of model performance.
    """
    df = pd.DataFrame(results)
    df_sorted = df.sort_values(by="r2", ascending=False)
    
    print("\n" + "="*80)
    print("                      MACHINE LEARNING MODEL EVALUATION SUMMARY")
    print("="*80)
    header = f"{'Model Name':<28} | {'MAE (INR)':<12} | {'RMSE (INR)':<14} | {'R² Score':<9} | {'MAPE (%)':<8}"
    print(header)
    print("-" * len(header))
    for _, row in df_sorted.iterrows():
        print(f"{row['model_name']:<28} | ₹{row['mae']:>10,.0f} | ₹{row['rmse']:>12,.0f} | {row['r2']:>8.4f}  | {row['mape']:>6.2f}%")
    print("="*80)
    best = df_sorted.iloc[0]
    print(f"🏆 BEST PERFORMING MODEL: {best['model_name']} (R²: {best['r2']:.4f}, RMSE: ₹{best['rmse']:,.0f})\n")
    return df_sorted
