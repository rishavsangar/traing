"""
Model Training, Comparison, Hyperparameter Tuning & Persistence
Project: House Price Prediction Using Machine Learning
Trains 5 ML algorithms, evaluates them, tunes hyperparameters,
and persists artifacts via Joblib.
"""

import os
import json
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

# Try importing XGBoost; fall back cleanly if native binary is missing
try:
    from xgboost import XGBRegressor
    HAS_XGBOOST = True
except ImportError:
    from sklearn.ensemble import HistGradientBoostingRegressor as XGBRegressor
    HAS_XGBOOST = False

from backend.ml.generate_dataset import generate_housing_dataset
from backend.ml.preprocessing import (
    prepare_data_for_training,
    build_column_transformer,
    ALL_NUMERICAL_FEATURES,
    ALL_CATEGORICAL_FEATURES
)
from backend.ml.evaluate import evaluate_model, print_evaluation_summary

def run_training_pipeline(dataset_path: str = None, models_dir: str = None, tune_hyperparams: bool = True):
    """
    Complete end-to-end training, evaluation, tuning and persistence workflow.
    """
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if dataset_path is None:
        dataset_path = os.path.join(base_dir, "data", "raw_house_prices.csv")
    if models_dir is None:
        models_dir = os.path.join(base_dir, "models")
    
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(os.path.dirname(dataset_path), exist_ok=True)

    # 1. Load or Generate Dataset
    if not os.path.exists(dataset_path):
        print("Raw dataset not found. Generating realistic dataset...")
        raw_df = generate_housing_dataset(n_samples=12500, output_path=dataset_path)
    else:
        print(f"Loading existing dataset from: {dataset_path}")
        raw_df = pd.read_csv(dataset_path)

    # 2. Preprocess & Feature Engineering
    print("Preprocessing data and engineering features...")
    X, y, cleaned_df = prepare_data_for_training(raw_df)

    # Save cleaned dataset for analytics & SQLite
    cleaned_csv_path = os.path.join(base_dir, "data", "cleaned_house_prices.csv")
    cleaned_df.to_csv(cleaned_csv_path, index=False)
    print(f"Cleaned dataset saved: {cleaned_csv_path} ({len(cleaned_df)} records)")

    # 3. Train/Test Split (80% Train, 20% Test, random_state=42)
    print("Splitting dataset into 80% Train / 20% Test (random_state=42)...")
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )

    # 4. Fit ColumnTransformer on Training Data
    print("Fitting ColumnTransformer on training features...")
    preprocessor = build_column_transformer()
    X_train_transformed = preprocessor.fit_transform(X_train_raw)
    X_test_transformed = preprocessor.transform(X_test_raw)

    # 5. Define Candidate Models
    candidate_models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=12, random_state=42),
        "Random Forest": RandomForestRegressor(n_estimators=100, max_depth=16, random_state=42, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=120, learning_rate=0.1, max_depth=5, random_state=42),
    }

    if HAS_XGBOOST:
        candidate_models["XGBoost"] = XGBRegressor(
            n_estimators=150,
            learning_rate=0.08,
            max_depth=6,
            subsample=0.85,
            colsample_bytree=0.85,
            random_state=42,
            n_jobs=-1
        )
    else:
        candidate_models["XGBoost (HistGradient)"] = XGBRegressor(
            max_iter=150,
            learning_rate=0.08,
            max_depth=6,
            random_state=42
        )

    # 6. Train & Evaluate All Models
    evaluation_results = []
    trained_models = {}

    for name, model in candidate_models.items():
        print(f"Training {name}...")
        model.fit(X_train_transformed, y_train)
        y_pred = model.predict(X_test_transformed)
        metrics = evaluate_model(y_test, y_pred, model_name=name)
        evaluation_results.append(metrics)
        trained_models[name] = model

    # Print baseline comparison
    print_evaluation_summary(evaluation_results)

    # 7. Hyperparameter Tuning on Top Candidate
    best_candidate_name = max(evaluation_results, key=lambda m: m["r2"])["model_name"]
    print(f"Top performing base model: {best_candidate_name}. Initiating Hyperparameter Tuning...")

    tuned_model = None
    tuning_metrics = None

    if tune_hyperparams:
        if "Random Forest" in best_candidate_name:
            param_grid = {
                "n_estimators": [100, 150, 200],
                "max_depth": [14, 18, 22],
                "min_samples_split": [2, 4],
                "min_samples_leaf": [1, 2]
            }
            search = RandomizedSearchCV(
                RandomForestRegressor(random_state=42, n_jobs=-1),
                param_distributions=param_grid,
                n_iter=6,
                cv=3,
                scoring="r2",
                random_state=42,
                n_jobs=-1
            )
        elif "Gradient Boosting" in best_candidate_name:
            param_grid = {
                "n_estimators": [120, 180, 220],
                "learning_rate": [0.05, 0.08, 0.12],
                "max_depth": [4, 6, 8],
                "subsample": [0.8, 0.9, 1.0]
            }
            search = RandomizedSearchCV(
                GradientBoostingRegressor(random_state=42),
                param_distributions=param_grid,
                n_iter=6,
                cv=3,
                scoring="r2",
                random_state=42,
                n_jobs=-1
            )
        else: # XGBoost
            param_grid = {
                "n_estimators": [120, 180, 240],
                "learning_rate": [0.04, 0.08, 0.12],
                "max_depth": [5, 6, 8],
                "subsample": [0.8, 0.9, 1.0]
            }
            search = RandomizedSearchCV(
                candidate_models[best_candidate_name],
                param_distributions=param_grid,
                n_iter=6,
                cv=3,
                scoring="r2",
                random_state=42,
                n_jobs=-1
            )

        print("Executing RandomizedSearchCV...")
        search.fit(X_train_transformed, y_train)
        tuned_model = search.best_estimator_
        print(f"Optimal Hyperparameters: {search.best_params_}")

        y_tuned_pred = tuned_model.predict(X_test_transformed)
        tuned_metrics = evaluate_model(y_test, y_tuned_pred, model_name=f"{best_candidate_name} (Tuned)")
        evaluation_results.append(tuned_metrics)
        trained_models[f"{best_candidate_name} (Tuned)"] = tuned_model
        print(f"Tuned Model R²: {tuned_metrics['r2']} | RMSE: ₹{tuned_metrics['rmse']:,.0f}")

    # 8. Select Overall Best Model
    summary_df = print_evaluation_summary(evaluation_results)
    best_record = summary_df.iloc[0].to_dict()
    best_model_name = best_record["model_name"]
    final_best_model = trained_models[best_model_name]

    # Tag 'is_best_model' boolean
    for res in evaluation_results:
        res["is_best_model"] = (res["model_name"] == best_model_name)

    # 9. Extract Feature Importances if available
    feature_importances = []
    try:
        # Get one-hot feature names
        cat_encoder = preprocessor.named_transformers_["cat"].named_steps["encoder"]
        cat_feature_names = list(cat_encoder.get_feature_names_out(ALL_CATEGORICAL_FEATURES))
        all_feature_names = ALL_NUMERICAL_FEATURES + cat_feature_names

        if hasattr(final_best_model, "feature_importances_"):
            raw_importances = final_best_model.feature_importances_
            importance_df = pd.DataFrame({
                "feature": all_feature_names,
                "importance": raw_importances
            }).sort_values(by="importance", ascending=False)

            # Aggregate top features
            for _, row in importance_df.head(15).iterrows():
                feature_importances.append({
                    "feature": row["feature"],
                    "importance": round(float(row["importance"]) * 100, 2)
                })
    except Exception as e:
        print(f"Notice: Feature importance extraction note: {e}")

    # 10. Persist Model, Preprocessing Pipeline, and Metrics
    model_path = os.path.join(models_dir, "house_price_model.joblib")
    preprocessor_path = os.path.join(models_dir, "preprocessing_pipeline.joblib")
    metrics_path = os.path.join(models_dir, "model_metrics.json")

    joblib.dump(final_best_model, model_path)
    joblib.dump(preprocessor, preprocessor_path)

    metrics_payload = {
        "best_model_name": best_model_name,
        "best_r2_score": best_record["r2"],
        "best_rmse": best_record["rmse"],
        "best_mae": best_record["mae"],
        "best_mape": best_record["mape"],
        "models": evaluation_results,
        "feature_importances": feature_importances,
        "trained_samples": len(X_train_raw),
        "test_samples": len(X_test_raw),
        "total_samples": len(cleaned_df)
    }

    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics_payload, f, indent=2)

    print(f"\nArtifacts successfully persisted:")
    print(f" -> Model: {model_path}")
    print(f" -> Preprocessor: {preprocessor_path}")
    print(f" -> Metrics JSON: {metrics_path}")

    return metrics_payload

if __name__ == "__main__":
    run_training_pipeline()
