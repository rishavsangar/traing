"""
Pydantic Schemas & Validation Models
Project: House Price Prediction Using Machine Learning
Enforces strict input validation constraints and structured response types.
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, model_validator

VALID_LOCATIONS = [
    "Delhi", "Mumbai", "Bangalore", "Hyderabad", "Chandigarh",
    "Mohali", "Jalandhar", "Ludhiana", "Amritsar", "Pune",
    "Jaipur", "Noida", "Gurgaon"
]

VALID_PROPERTY_TYPES = [
    "Apartment", "Independent House", "Villa", "Builder Floor", "Penthouse"
]

VALID_FURNISHINGS = [
    "Unfurnished", "Semi-Furnished", "Fully-Furnished"
]

class PredictionRequest(BaseModel):
    location: str = Field(..., description="Indian city name", example="Jalandhar")
    area_sqft: float = Field(..., gt=0, description="Total property area in square feet", example=1800.0)
    bedrooms: int = Field(..., ge=1, le=10, description="Number of bedrooms (BHK)", example=3)
    bathrooms: int = Field(..., ge=1, le=10, description="Number of bathrooms", example=2)
    property_age: int = Field(..., ge=0, le=100, description="Age of property in years", example=5)
    parking: int = Field(default=1, ge=0, le=5, description="Number of dedicated parking spots", example=1)
    floor: int = Field(default=1, ge=0, le=100, description="Current floor level (0 for ground)", example=2)
    total_floors: int = Field(default=4, ge=1, le=100, description="Total number of floors in building", example=4)
    furnishing_status: str = Field(default="Semi-Furnished", description="Furnishing level", example="Semi-Furnished")
    balconies: int = Field(default=1, ge=0, le=10, description="Number of balconies", example=2)
    property_type: str = Field(default="Apartment", description="Category of real estate", example="Apartment")
    distance_school_km: float = Field(default=1.5, ge=0.0, le=50.0, description="Distance to closest school (km)", example=1.2)
    distance_hospital_km: float = Field(default=2.0, ge=0.0, le=50.0, description="Distance to nearest hospital (km)", example=2.0)
    distance_market_km: float = Field(default=1.0, ge=0.0, le=50.0, description="Distance to commercial market (km)", example=0.8)
    distance_metro_km: float = Field(default=3.0, ge=0.0, le=50.0, description="Distance to nearest metro/rail station (km)", example=3.5)
    nearby_school: int = Field(default=1, ge=0, le=1, description="Binary indicator: school within 2km", example=1)
    nearby_hospital: int = Field(default=1, ge=0, le=1, description="Binary indicator: hospital within 2.5km", example=1)
    nearby_market: int = Field(default=1, ge=0, le=1, description="Binary indicator: market within 1.5km", example=1)

    @model_validator(mode="after")
    def validate_logical_constraints(self):
        if self.floor > self.total_floors:
            raise ValueError(f"Floor ({self.floor}) cannot exceed Total Floors ({self.total_floors}).")
        
        # Standardize strings
        loc = self.location.strip().title()
        if loc not in VALID_LOCATIONS:
            raise ValueError(f"Invalid location '{self.location}'. Supported cities: {', '.join(VALID_LOCATIONS)}")
        self.location = loc

        ptype = self.property_type.strip().title()
        if ptype not in [p.title() for p in VALID_PROPERTY_TYPES]:
            raise ValueError(f"Invalid property_type '{self.property_type}'. Supported types: {', '.join(VALID_PROPERTY_TYPES)}")
        self.property_type = ptype

        furn = self.furnishing_status.strip().title()
        if furn not in [f.title() for f in VALID_FURNISHINGS]:
            raise ValueError(f"Invalid furnishing_status '{self.furnishing_status}'. Supported: {', '.join(VALID_FURNISHINGS)}")
        self.furnishing_status = furn

        return self

class PredictionResponse(BaseModel):
    predicted_price: int = Field(..., description="Estimated selling price in INR (₹)")
    model: str = Field(..., description="Machine learning algorithm name used")
    r2_score: float = Field(..., description="Actual model evaluation R² test score")
    estimated_low: int = Field(..., description="Lower confidence estimate in INR")
    estimated_high: int = Field(..., description="Upper confidence estimate in INR")
    formatted_price: str = Field(..., description="Indian currency string e.g. ₹62.40 Lakhs")
    formatted_range: str = Field(..., description="Formatted price range e.g. ₹58.00 L – ₹67.00 L")

class PredictionHistoryItem(BaseModel):
    id: int
    location: str
    area_sqft: float
    bedrooms: int
    bathrooms: int
    property_type: str
    furnishing_status: str
    predicted_price: float
    estimated_low: float
    estimated_high: float
    model_name: str
    r2_score: float
    created_at: datetime

    class Config:
        from_attributes = True

class ModelMetricItem(BaseModel):
    model_name: str
    mae: float
    mse: float
    rmse: float
    r2: float
    mape: float
    is_best_model: bool

class FeatureImportanceItem(BaseModel):
    feature: str
    importance: float

class ModelComparisonResponse(BaseModel):
    best_model_name: str
    best_r2_score: float
    best_rmse: float
    best_mae: float
    best_mape: float
    models: List[ModelMetricItem]
    feature_importances: List[FeatureImportanceItem]
    total_samples: int
    trained_samples: int
    test_samples: int

class CityAnalytics(BaseModel):
    location: str
    count: int
    avg_price: float
    median_price: float
    avg_price_per_sqft: float

class PriceDistributionBin(BaseModel):
    bin_range: str
    min_val: float
    max_val: float
    count: int

class AnalyticsSummaryResponse(BaseModel):
    total_properties: int
    average_price: float
    median_price: float
    average_price_per_sqft: float
    most_expensive_location: str
    cheapest_location: str
    city_analytics: List[CityAnalytics]
    price_distribution: List[PriceDistributionBin]
    area_vs_price_samples: List[Dict[str, Any]]
    bedroom_distribution: List[Dict[str, Any]]
