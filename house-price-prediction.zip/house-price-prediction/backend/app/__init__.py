"""
House Price Prediction - FastAPI Application Package
"""
