"""
SQLAlchemy ORM Models
Project: House Price Prediction Using Machine Learning
Defines tables: properties, predictions, and model_metrics.
"""

from datetime import datetime
from sqlalchemy import Column, Integer, Float, String, Boolean, DateTime
from backend.app.database import Base

class Property(Base):
    __tablename__ = "properties"

    id = Column(Integer, primary_key=True, index=True)
    location = Column(String(100), nullable=False, index=True)
    area_sqft = Column(Float, nullable=False)
    bedrooms = Column(Integer, nullable=False)
    bathrooms = Column(Integer, nullable=False)
    property_age = Column(Integer, nullable=False)
    parking = Column(Integer, default=1)
    floor = Column(Integer, default=1)
    total_floors = Column(Integer, default=4)
    furnishing_status = Column(String(50), nullable=False)
    balconies = Column(Integer, default=1)
    property_type = Column(String(50), nullable=False)
    distance_school_km = Column(Float, default=2.0)
    distance_hospital_km = Column(Float, default=2.5)
    distance_market_km = Column(Float, default=1.5)
    distance_metro_km = Column(Float, default=3.0)
    nearby_school = Column(Integer, default=1)
    nearby_hospital = Column(Integer, default=1)
    nearby_market = Column(Integer, default=1)
    price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True)
    location = Column(String(100), nullable=False)
    area_sqft = Column(Float, nullable=False)
    bedrooms = Column(Integer, nullable=False)
    bathrooms = Column(Integer, nullable=False)
    property_age = Column(Integer, nullable=False)
    parking = Column(Integer, default=1)
    floor = Column(Integer, default=1)
    total_floors = Column(Integer, default=4)
    furnishing_status = Column(String(50), nullable=False)
    balconies = Column(Integer, default=1)
    property_type = Column(String(50), nullable=False)
    predicted_price = Column(Float, nullable=False)
    estimated_low = Column(Float, nullable=False)
    estimated_high = Column(Float, nullable=False)
    model_name = Column(String(100), nullable=False)
    r2_score = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class ModelMetric(Base):
    __tablename__ = "model_metrics"

    id = Column(Integer, primary_key=True, index=True)
    model_name = Column(String(100), nullable=False, unique=True)
    mae = Column(Float, nullable=False)
    mse = Column(Float, nullable=False)
    rmse = Column(Float, nullable=False)
    r2 = Column(Float, nullable=False)
    mape = Column(Float, nullable=False)
    is_best_model = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
