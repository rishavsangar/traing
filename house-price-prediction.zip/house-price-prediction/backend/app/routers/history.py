"""
Prediction History Router: GET /api/predictions/history
Project: House Price Prediction Using Machine Learning
"""

from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from backend.app.database import get_db
from backend.app.models import Prediction
from backend.app.schemas import PredictionHistoryItem

router = APIRouter(prefix="/api/predictions", tags=["History"])

@router.get("/history", response_model=List[PredictionHistoryItem], status_code=status.HTTP_200_OK)
def get_prediction_history(
    limit: int = Query(50, ge=1, le=200, description="Max records to retrieve"),
    offset: int = Query(0, ge=0, description="Number of records to skip"),
    db: Session = Depends(get_db)
):
    """
    Retrieves stored historical house price predictions from the SQLite database.
    """
    try:
        records = (
            db.query(Prediction)
            .order_by(desc(Prediction.created_at))
            .offset(offset)
            .limit(limit)
            .all()
        )
        return records
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch prediction history: {str(e)}"
        )

@router.delete("/history", status_code=status.HTTP_200_OK)
def clear_history(db: Session = Depends(get_db)):
    """
    Clears all saved prediction history logs.
    """
    try:
        deleted_count = db.query(Prediction).delete()
        db.commit()
        return {"message": "Prediction history cleared successfully", "deleted_records": deleted_count}
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to clear history: {str(e)}"
        )
