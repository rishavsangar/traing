"""
Prediction Router: POST /api/predict
Project: House Price Prediction Using Machine Learning
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.app.schemas import PredictionRequest, PredictionResponse
from backend.app.services.ml_service import predict_house_price

router = APIRouter(prefix="/api", tags=["Prediction"])

@router.post("/predict", response_model=PredictionResponse, status_code=status.HTTP_200_OK)
def predict_price(request: PredictionRequest, db: Session = Depends(get_db)):
    """
    Receives house property attributes, computes valuation using the trained ML model,
    calculates empirical confidence bounds, records prediction in database, and returns results.
    """
    try:
        response = predict_house_price(request, db)
        return response
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(ve))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Inference error during price estimation: {str(e)}"
        )
