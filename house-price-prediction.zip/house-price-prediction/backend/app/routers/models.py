"""
Model Metrics Router: GET /api/models
Project: House Price Prediction Using Machine Learning
"""

from fastapi import APIRouter, HTTPException, status
from backend.app.schemas import ModelComparisonResponse
from backend.app.services.ml_service import get_model_comparison_metrics

router = APIRouter(prefix="/api", tags=["Model Comparison"])

@router.get("/models", response_model=ModelComparisonResponse, status_code=status.HTTP_200_OK)
def get_model_metrics():
    """
    Returns actual evaluated performance metrics (MAE, RMSE, R², MAPE)
    across all trained machine learning models along with feature importances.
    """
    try:
        return get_model_comparison_metrics()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to load model comparison metrics: {str(e)}"
        )
