"""
Analytics Router: GET /api/analytics
Project: House Price Prediction Using Machine Learning
"""

from fastapi import APIRouter, HTTPException, status
from backend.app.schemas import AnalyticsSummaryResponse
from backend.app.services.ml_service import get_analytics_data

router = APIRouter(prefix="/api", tags=["Analytics"])

@router.get("/analytics", response_model=AnalyticsSummaryResponse, status_code=status.HTTP_200_OK)
def get_analytics():
    """
    Returns aggregated metrics, distribution histograms, city breakdown,
    and scatter plot samples from the housing dataset for Recharts visualization.
    """
    try:
        return get_analytics_data()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate dataset analytics: {str(e)}"
        )
