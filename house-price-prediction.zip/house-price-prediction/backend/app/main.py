"""
FastAPI Main Application Entrypoint
Project: House Price Prediction Using Machine Learning
Assembles CORS, database lifecycle, routers, health checks, and metadata.
"""

import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.app.database import init_db
from backend.app.routers import predict, analytics, models, history
from backend.app.schemas import VALID_LOCATIONS, VALID_PROPERTY_TYPES, VALID_FURNISHINGS
from backend.app.services.ml_service import predictor_instance

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup & Shutdown lifecycle events.
    """
    print("Initializing Database tables...")
    init_db()
    
    # Check if ML model is ready; if not, initiate background load
    if not predictor_instance.is_ready():
        print("Checking for existing trained ML model artifacts...")
        predictor_instance.load_artifacts()
        if not predictor_instance.is_ready():
            print("Model artifacts not yet found on disk. Run `python backend/ml/train.py` to train.")

    yield
    print("Application shutdown complete.")

app = FastAPI(
    title="House Price Prediction API",
    description="Production-grade Data Science & Machine Learning REST API for Indian Real Estate Valuation.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS Configuration for React Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, restrict to specific frontend domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(predict.router)
app.include_router(analytics.router)
app.include_router(models.router)
app.include_router(history.router)

@app.get("/", tags=["General"])
def root():
    return {
        "project": "House Price Prediction Using Machine Learning",
        "description": "Production REST API for House Price Estimation, Analytics & Model Evaluation",
        "swagger_docs": "/docs",
        "endpoints": {
            "predict": "POST /api/predict",
            "analytics": "GET /api/analytics",
            "models": "GET /api/models",
            "history": "GET /api/predictions/history",
            "health": "GET /api/health",
            "locations": "GET /api/locations"
        },
        "status": "online"
    }

@app.get("/api/health", tags=["General"])
def health_check():
    """
    System health and model readiness check.
    """
    model_ready = predictor_instance.is_ready()
    return {
        "status": "healthy" if model_ready else "initializing",
        "database": "connected (SQLite)",
        "model_loaded": model_ready,
        "best_model_name": predictor_instance.metrics.get("best_model_name", "None") if predictor_instance.metrics else "Not Loaded",
        "version": "1.0.0"
    }

@app.get("/api/locations", tags=["General"])
def get_supported_metadata():
    """
    Returns lists of supported Indian cities, property types, and furnishing choices.
    """
    return {
        "locations": VALID_LOCATIONS,
        "property_types": VALID_PROPERTY_TYPES,
        "furnishing_statuses": VALID_FURNISHINGS,
        "presets": [
            {
                "label": "Modern 3BHK Apartment - Bangalore",
                "description": "Mid-floor spacious apartment near Whitefield IT corridor",
                "data": {
                    "location": "Bangalore",
                    "area_sqft": 1650,
                    "bedrooms": 3,
                    "bathrooms": 2,
                    "property_age": 3,
                    "parking": 1,
                    "floor": 4,
                    "total_floors": 14,
                    "furnishing_status": "Semi-Furnished",
                    "balconies": 2,
                    "property_type": "Apartment",
                    "distance_school_km": 1.2,
                    "distance_hospital_km": 1.8,
                    "distance_market_km": 0.6,
                    "distance_metro_km": 1.5,
                    "nearby_school": 1,
                    "nearby_hospital": 1,
                    "nearby_market": 1
                }
            },
            {
                "label": "Luxury 4BHK Villa - Gurgaon",
                "description": "Premium gated villa on Golf Course Road",
                "data": {
                    "location": "Gurgaon",
                    "area_sqft": 3800,
                    "bedrooms": 4,
                    "bathrooms": 5,
                    "property_age": 2,
                    "parking": 2,
                    "floor": 0,
                    "total_floors": 2,
                    "furnishing_status": "Fully-Furnished",
                    "balconies": 3,
                    "property_type": "Villa",
                    "distance_school_km": 0.8,
                    "distance_hospital_km": 1.2,
                    "distance_market_km": 1.0,
                    "distance_metro_km": 2.0,
                    "nearby_school": 1,
                    "nearby_hospital": 1,
                    "nearby_market": 1
                }
            },
            {
                "label": "Independent House - Chandigarh",
                "description": "Classic single-family home in prime residential sector",
                "data": {
                    "location": "Chandigarh",
                    "area_sqft": 2400,
                    "bedrooms": 3,
                    "bathrooms": 3,
                    "property_age": 8,
                    "parking": 2,
                    "floor": 0,
                    "total_floors": 2,
                    "furnishing_status": "Semi-Furnished",
                    "balconies": 2,
                    "property_type": "Independent House",
                    "distance_school_km": 0.5,
                    "distance_hospital_km": 1.5,
                    "distance_market_km": 0.4,
                    "distance_metro_km": 5.0,
                    "nearby_school": 1,
                    "nearby_hospital": 1,
                    "nearby_market": 1
                }
            },
            {
                "label": "Budget 2BHK Flat - Mohali",
                "description": "Affordable ready-to-move apartment near Airport Road",
                "data": {
                    "location": "Mohali",
                    "area_sqft": 1150,
                    "bedrooms": 2,
                    "bathrooms": 2,
                    "property_age": 4,
                    "parking": 1,
                    "floor": 2,
                    "total_floors": 6,
                    "furnishing_status": "Unfurnished",
                    "balconies": 1,
                    "property_type": "Apartment",
                    "distance_school_km": 1.5,
                    "distance_hospital_km": 2.5,
                    "distance_market_km": 1.0,
                    "distance_metro_km": 6.0,
                    "nearby_school": 1,
                    "nearby_hospital": 0,
                    "nearby_market": 1
                }
            },
            {
                "label": "Sea-View 2BHK Apartment - Mumbai",
                "description": "High-rise prime location apartment in suburban Mumbai",
                "data": {
                    "location": "Mumbai",
                    "area_sqft": 950,
                    "bedrooms": 2,
                    "bathrooms": 2,
                    "property_age": 5,
                    "parking": 1,
                    "floor": 16,
                    "total_floors": 28,
                    "furnishing_status": "Fully-Furnished",
                    "balconies": 2,
                    "property_type": "Apartment",
                    "distance_school_km": 0.7,
                    "distance_hospital_km": 1.1,
                    "distance_market_km": 0.3,
                    "distance_metro_km": 0.5,
                    "nearby_school": 1,
                    "nearby_hospital": 1,
                    "nearby_market": 1
                }
            }
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="127.0.0.1", port=8000, reload=True)
