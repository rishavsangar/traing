# Chapter 8: Exploratory Data Analysis (EDA)

## 8.1 Univariate Analysis

### 8.1.1 Target Variable (`price`) Distribution
The target variable exhibits a right-skewed distribution typical of real estate pricing. The bulk of properties are centered between ₹35 Lakhs and ₹1.5 Crores, with luxury penthouses and high-end villas extending into the ₹3.5 Cr to ₹7.5 Cr bracket.

- **Mean Price:** $\approx$ ₹98.4 Lakhs
- **Median Price:** $\approx$ ₹74.5 Lakhs
- **Standard Deviation:** $\approx$ ₹68.2 Lakhs

### 8.1.2 Square Footage (`area_sqft`) Distribution
Property area spans from 450 sq.ft (compact 1BHK flats) to 5,500+ sq.ft (sprawling luxury villas), with the median centered around 1,450 sq.ft.

## 8.2 Bivariate & Multi-Feature Relationships

### 8.2.1 Location vs. Average Price (₹ Lakhs)
Tier-1 metropolitan areas exhibit high base land valuations, leading to distinct tier clustering:
1. **Tier-1 Premium:** Mumbai (Avg: ₹2.25 Cr, Rate: ₹22,000/sqft), Delhi (Avg: ₹1.45 Cr, Rate: ₹12,500/sqft), Gurgaon (Avg: ₹1.38 Cr, Rate: ₹11,500/sqft).
2. **Tech & Commercial Growth Centers:** Bangalore (Avg: ₹1.05 Cr, Rate: ₹9,200/sqft), Hyderabad (Avg: ₹92 Lakhs, Rate: ₹7,800/sqft), Pune (Avg: ₹88 Lakhs, Rate: ₹7,500/sqft), Noida (Avg: ₹85 Lakhs, Rate: ₹7,200/sqft).
3. **Established Regional & Emerging Cities:** Chandigarh (Avg: ₹82 Lakhs, Rate: ₹6,800/sqft), Mohali (Avg: ₹64 Lakhs, Rate: ₹5,200/sqft), Jaipur (Avg: ₹58 Lakhs, Rate: ₹4,500/sqft), Ludhiana (Avg: ₹52 Lakhs, Rate: ₹4,100/sqft), Amritsar (Avg: ₹48 Lakhs, Rate: ₹3,800/sqft), Jalandhar (Avg: ₹45 Lakhs, Rate: ₹3,600/sqft).

### 8.2.2 Property Type & Bedroom Count
- **Apartments:** Dominate the sample volume (~55%), showing strong correlation between floor level and view premiums.
- **Villas & Penthouses:** Exhibit super-linear price scaling due to private land footprint, higher bathroom counts, and dedicated multiple parking bays.

### 8.2.3 Correlation Matrix Highlights
- `area_sqft` demonstrates the highest positive linear correlation with `price` ($r \approx 0.78$).
- `bedrooms` and `bathrooms` correlate strongly with area ($r > 0.65$) and price ($r \approx 0.62$).
- `distance_metro_km` exhibits a negative correlation ($r \approx -0.32$), confirming that proximity to transit corridors elevates property valuation.
