# Chapter 5: Methodology

## 5.1 System Architecture

The project adopts a decoupled, layered microservice architecture divided into three primary modules:
1. **Data Science & ML Pipeline:** Offline & batch training, feature transformation, hyperparameter tuning, model evaluation, and Joblib artifact serialization.
2. **FastAPI Backend Server:** Lightweight, high-throughput asynchronous REST server exposing inference, dataset analytics, and audit logging endpoints.
3. **React Client Application:** Single Page Application (SPA) built with Vite and Recharts providing an intuitive interface for interactive property estimation.

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                             DATA SCIENCE CORE                               │
│                                                                             │
│  [12,500+ Housing Data] ──► [IQR Cleaning & Imputation] ──► [Feature Eng.]  │
│                                                                    │        │
│  [Joblib Serialization] ◄── [Hyperparameter Tuning] ◄── [Model Evaluation] │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │ Saved Artifacts (.joblib & .json)
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            FASTAPI REST BACKEND                             │
│                                                                             │
│  POST /api/predict     ──► [ColumnTransformer] ──► [ML Model] ──► Response │
│  GET  /api/analytics   ──► [Aggregated Stats]  ──► Recharts Payload         │
│  GET  /api/models      ──► [Evaluation Table]  ──► Leaderboard JSON         │
│  GET  /api/history     ──► [SQLite Database]   ──► Auditable Prediction Log │
└──────────────────────────────────────▲──────────────────────────────────────┘
                                       │ HTTP / JSON REST
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       REACT (VITE + RECHARTS) FRONTEND                      │
│                                                                             │
│  [🏠 Predictor Page]    [📊 Dataset Analytics]   [🤖 Model Comparison]      │
│  [📜 Prediction Log]    [📖 Architecture Docs]   [⚡ One-Click Presets]     │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 5.2 Step-by-Step Data Science Workflow

1. **Data Ingestion:** Reading 12,500+ records across 19 feature columns.
2. **Data Cleansing:** Pruning duplicate feature combinations and filtering out-of-boundary samples.
3. **Outlier Mitigation:** Truncating extreme 1% tails on price and square footage using Interquartile Range boundaries.
4. **Feature Derivation:** Creating composite scores (`total_rooms`, `amenity_score`, `distance_score`, `floor_ratio`, `property_age_group`).
5. **Preprocessing Assembler:**
   - Numerical columns: `SimpleImputer(strategy='median')` followed by `StandardScaler()`.
   - Categorical columns: `SimpleImputer(strategy='most_frequent')` followed by `OneHotEncoder(handle_unknown='ignore')`.
6. **Data Partitioning:** Deterministic 80% training set and 20% holdout testing set (`random_state=42`).
7. **Model Training:** Fitting Linear Regression, Decision Trees, Random Forests, Gradient Boosters, and XGBoost.
8. **Hyperparameter Tuning:** Cross-validated `RandomizedSearchCV` exploring depth, estimators, learning rate, and subsampling.
9. **Artifact Serialization:** Serializing the winning model and transformer into `models/house_price_model.joblib`.
10. **Application Integration:** Serving predictions via FastAPI REST endpoints and visualizing results in React.
