# Algorithm Formulations & Comparative Theoretical Breakdown

## 1. Algorithm Complexity Analysis

| Algorithm | Training Time Complexity | Inference Time Complexity | Space Complexity |
| :--- | :--- | :--- | :--- |
| **Linear Regression** | $\mathcal{O}(d^2 n + d^3)$ | $\mathcal{O}(d)$ | $\mathcal{O}(d)$ |
| **Decision Tree** | $\mathcal{O}(n \cdot d \cdot \log n)$ | $\mathcal{O}(\text{depth})$ | $\mathcal{O}(\text{nodes})$ |
| **Random Forest** | $\mathcal{O}(B \cdot n \cdot d' \cdot \log n)$ | $\mathcal{O}(B \cdot \text{depth})$ | $\mathcal{O}(B \cdot \text{nodes})$ |
| **Gradient Boosting** | $\mathcal{O}(M \cdot n \cdot d \cdot \text{depth})$ | $\mathcal{O}(M \cdot \text{depth})$ | $\mathcal{O}(M \cdot \text{nodes})$ |
| **XGBoost** | $\mathcal{O}(M \cdot \|x\|_0 \cdot \log n)$ | $\mathcal{O}(M \cdot \text{depth})$ | $\mathcal{O}(M \cdot \text{nodes})$ |

*Notation:* $n = \text{samples}$, $d = \text{features}$, $B = \text{trees in forest}$, $M = \text{boosting iterations}$, $\|x\|_0 = \text{non-zero feature entries}$.

---

## 2. Evaluation Metric Definitions

### Mean Absolute Error (MAE)
$$\text{MAE} = \frac{1}{n} \sum_{i=1}^n |y_i - \hat{y}_i|$$
Measures the average magnitude of absolute errors in the original monetary units (INR ₹). Robust to large outlier residuals.

### Root Mean Squared Error (RMSE)
$$\text{RMSE} = \sqrt{\frac{1}{n} \sum_{i=1}^n (y_i - \hat{y}_i)^2}$$
Penalizes larger errors disproportionately due to the quadratic term, providing a standard gauge for variance dispersion.

### Coefficient of Determination ($R^2$ Score)
$$R^2 = 1 - \frac{\sum_{i=1}^n (y_i - \hat{y}_i)^2}{\sum_{i=1}^n (y_i - \bar{y})^2} = 1 - \frac{\text{SS}_{\text{res}}}{\text{SS}_{\text{tot}}}$$
Quantifies the proportion of variance in housing price explained by the independent feature vector $\mathbf{x}$.

### Mean Absolute Percentage Error (MAPE)
$$\text{MAPE} = \frac{100\%}{n} \sum_{i=1}^n \left| \frac{y_i - \hat{y}_i}{y_i} \right|$$
Yields a percentage-based evaluation of error scale relative to property magnitude.
