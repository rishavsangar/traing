# Chapter 2: Problem Statement

## 2.1 Formal Problem Definition

Given a vector of residential property features $\mathbf{x} \in \mathbb{R}^d$ comprising physical attributes, location metadata, building age, floor positioning, and spatial connectivity metrics:

$$\mathbf{x} = \left[ x_{\text{location}}, x_{\text{area}}, x_{\text{bedrooms}}, x_{\text{bathrooms}}, x_{\text{age}}, x_{\text{parking}}, x_{\text{floor}}, x_{\text{type}}, x_{\text{furnishing}}, x_{\text{dist\_metro}}, \dots \right]^T$$

The objective is to learn a mapping function $f: \mathbb{R}^d \to \mathbb{R}^+$ parameterized by $\theta$ such that the predicted selling price $\hat{y} = f(\mathbf{x}; \theta)$ minimizes the expected regression loss relative to the true transacted market price $y$:

$$\min_{\theta} \mathcal{L}(y, f(\mathbf{x}; \theta))$$

where the loss $\mathcal{L}$ is evaluated via Root Mean Squared Error (RMSE) and Mean Absolute Error (MAE):

$$\text{RMSE} = \sqrt{\frac{1}{N} \sum_{i=1}^{N} (y_i - \hat{y}_i)^2}$$

$$\text{MAE} = \frac{1}{N} \sum_{i=1}^{N} |y_i - \hat{y}_i|$$

## 2.2 Key Challenges

1. **Heterogeneous Feature Spaces:** Combining continuous numerical dimensions (square footage, distance in km) with high-cardinality nominal categories (cities, property types, furnishing grades).
2. **Non-Linear Geographic Dynamics:** Real estate value does not scale monotonically across geographical boundaries. A 1,500 sq.ft apartment in Mumbai command vastly higher base valuations than an identical unit in Jalandhar.
3. **Multi-Factor Interaction:** The value contribution of an additional bedroom depends tightly on square footage and city tier.
4. **Generalization & Overfitting:** Ensuring trained models generalize robustly to unseen testing data without overfitting to training noise.
5. **Operationalization:** Transitioning a theoretical Machine Learning model from offline Python notebooks into an interactive, low-latency web application accessible to end users.
