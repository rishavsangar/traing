# Chapter 7: Data Preprocessing & Feature Engineering

## 7.1 Data Cleaning Procedures

### 7.1.1 Duplicate Removal
Duplicate property records bias regression models by giving undue statistical weight to repeated observations. The cleaning pipeline strips duplicate rows based on feature column tuples:

$$\text{Unique Rows} = \text{DataFrame.drop\_duplicates(subset}=\mathbf{X}_{\text{features}}\text{)}$$

### 7.1.2 Logical Boundary Validation
Real estate attributes must adhere to physical constraints. The preprocessing script verifies:
- $\text{Area} > 0$ sq.ft
- $\text{Bedrooms} \ge 1$
- $\text{Bathrooms} \ge 1$
- $\text{Property Age} \ge 0$
- $\text{Floor} \le \text{Total Floors}$

### 7.1.3 Outlier Handling (IQR Filtering)
Extreme price skew can destabilize gradient calculations in regression models. Outlier thresholds are computed based on the 1st and 99th percentiles:

$$Q_1 = \text{Quantile}(0.01), \quad Q_3 = \text{Quantile}(0.99)$$
$$\text{Filtered Data} = \{x \mid Q_1 \le x_{\text{price}} \le Q_3 \land Q_1 \le x_{\text{area}} \le Q_3\}$$

## 7.2 Missing Value Imputation
Missing values are handled systematically using Scikit-Learn transformers:
- **Numerical Attributes** (e.g., `distance_metro_km`): Imputed using the **Median** value of the training subset to preserve resistance against skewed distributions.
- **Categorical Attributes** (e.g., `furnishing_status`): Imputed using the **Mode (Most Frequent)** category.

## 7.3 Domain Feature Engineering

To provide richer signals for machine learning estimators, five domain features are mathematically derived:

1. **Total Rooms:**
   $$\text{total\_rooms} = \text{bedrooms} + \text{bathrooms} + \text{balconies}$$
2. **Amenity Score:**
   $$\text{amenity\_score} = \text{nearby\_school} + \text{nearby\_hospital} + \text{nearby\_market} \quad (0 \le \text{score} \le 3)$$
3. **Distance Score (Inverse Connectivity Index):**
   $$\text{distance\_score} = \sum_{k \in \{\text{school, hosp, mkt, metro}\}} \frac{1}{1 + d_k}$$
4. **Property Age Group:**
   Categorical binning into `New (0-3 yrs)`, `Moderate (4-10 yrs)`, and `Old (10+ yrs)`.
5. **Floor Ratio:**
   $$\text{floor\_ratio} = \min\left(1.0, \frac{\text{floor}}{\max(\text{total\_floors}, 1)}\right)$$

## 7.4 Scikit-Learn ColumnTransformer Pipeline

```python
num_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

cat_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
])

preprocessor = ColumnTransformer(transformers=[
    ("num", num_pipeline, ALL_NUMERICAL_FEATURES),
    ("cat", cat_pipeline, ALL_CATEGORICAL_FEATURES)
])
```

By strictly fitting `preprocessor` only on the training set and using `.transform()` on testing and inference data, **zero data leakage** is guaranteed.
