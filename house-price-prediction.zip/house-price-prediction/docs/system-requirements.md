# Chapter 6: System Requirements

## 6.1 Software Requirements

| Component | Technology | Minimum Version | Description |
| :--- | :--- | :--- | :--- |
| **Operating System** | Windows / Linux / macOS | Windows 10+ / Ubuntu 20.04+ | Host operating system |
| **Programming Language** | Python | 3.9+ (Recommended: 3.10 / 3.11) | Core Data Science & backend runtime |
| **Data Manipulation** | Pandas, NumPy | Pandas $\ge 2.2.0$, NumPy $\ge 1.26.0$ | Dataframe operations and linear algebra |
| **Machine Learning** | Scikit-learn, XGBoost | Scikit-learn $\ge 1.4.0$, XGBoost $\ge 2.0.3$ | Estimators, transformers, and metrics |
| **Model Persistence** | Joblib | Joblib $\ge 1.3.2$ | High-throughput object serialization |
| **Backend Framework** | FastAPI, Uvicorn | FastAPI $\ge 0.110.0$, Uvicorn $\ge 0.28.0$ | Asynchronous ASGI REST server |
| **Data Validation** | Pydantic | Pydantic $\ge 2.6.0$ | Input parsing & strict constraint enforcement |
| **Database & ORM** | SQLAlchemy, SQLite | SQLAlchemy $\ge 2.0.28$ | Relational object-relational mapping |
| **Frontend Framework** | React, Vite | React 18+, Vite 5+ | Single Page Application framework |
| **Visualization** | Recharts, Matplotlib, Seaborn | Recharts $\ge 2.12.0$ | Declarative responsive interactive charting |
| **HTTP Client** | Axios | Axios $\ge 1.6.8$ | REST API requests & interceptors |

## 6.2 Hardware Requirements

- **Processor (CPU):** Intel Core i3 / AMD Ryzen 3 or higher (Multi-core recommended for parallel tree training with `n_jobs=-1`).
- **RAM:** Minimum 4 GB (8 GB or 16 GB recommended for multi-model cross-validation).
- **Storage:** 1 GB free disk space for dataset CSVs, virtual environment, Joblib model binaries, and node modules.
