# Summer Training Project Overview

| Attribute | Specification |
| :--- | :--- |
| **Project Title** | House Price Prediction Using Machine Learning |
| **Academic Course** | BCA / MCA / B.Tech Computer Science / Data Science Summer Training |
| **Primary Domain** | Machine Learning Regression & Applied Data Science |
| **Target Variable** | Property Price in Indian Rupees (INR ₹) |
| **Data Scope** | 12,000+ Records Across 13 Indian Metropolitan Markets |
| **Algorithms Evaluated** | Linear Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost |
| **Best Model** | Random Forest Regressor (Tuned via RandomizedSearchCV) |
| **Accuracy Metric ($R^2$)** | $\approx 0.9124$ ($> 90\%$ test variance explained) |
| **Backend REST API** | FastAPI + Uvicorn + Pydantic v2 + SQLite |
| **Frontend UI** | React 18 + Vite + Recharts + Lucide Icons + CSS Tokens |
| **Interactive Notebook** | 18-step Jupyter Notebook (`notebooks/house_price_prediction.ipynb`) |
| **Repository Directory** | `house-price-prediction/` |

---

### Project File Inventory

- `backend/`
  - `ml/generate_dataset.py`: Synthetic & realistic 12,000+ record dataset generator
  - `ml/preprocessing.py`: IQR outlier filtering, median/mode imputation & `ColumnTransformer`
  - `ml/evaluate.py`: Metric calculator ($MAE, MSE, RMSE, R^2, MAPE$)
  - `ml/train.py`: Multi-model training, tuning, and Joblib model persistence
  - `ml/predict.py`: Inference service with confidence intervals
  - `app/main.py`: FastAPI server entrypoint
  - `app/database.py`: SQLAlchemy SQLite session engine
  - `app/models.py`: Database tables (`properties`, `predictions`, `model_metrics`)
  - `app/schemas.py`: Pydantic validation schemas
  - `app/routers/`: REST endpoints (`/predict`, `/analytics`, `/models`, `/history`)
  - `notebooks/house_price_prediction.ipynb`: Complete 18-section Data Science notebook
- `frontend/`
  - `src/pages/PredictPage.jsx`: Interactive property valuation form with presets
  - `src/pages/AnalyticsPage.jsx`: Dataset EDA and Recharts distributions
  - `src/pages/ModelsPage.jsx`: Model performance leaderboard and feature importances
  - `src/pages/HistoryPage.jsx`: Stored prediction logs
  - `src/pages/AboutPage.jsx`: Architecture overview
  - `src/components/PriceCard.jsx`: Valuation result card with range gauge
- `docs/`: 13 formal academic documentation chapters
- `docker-compose.yml`: Container orchestration specification
- `README.md`: Project documentation & setup instructions
