# Chapter 3: Project Objectives

## 3.1 Primary Technical Objectives

The core objectives of this Summer Training Data Science project are structured as follows:

1. **Synthetic & Realistic Dataset Construction:**
   - Synthesize a comprehensive dataset comprising $\ge 10,000$ housing records across 13 Indian cities with genuine socio-economic valuation distributions and realistic stochastic noise.

2. **End-to-End Data Preprocessing & Cleaning:**
   - Detect and purge duplicate records.
   - Clean invalid numeric boundaries ($area \le 0, bedrooms \le 0$).
   - Impute missing features utilizing domain-appropriate statistical strategies (median for continuous metrics, mode for categorical attributes).
   - Identify and handle extreme price and area outliers via the Interquartile Range (IQR) technique.

3. **Domain Feature Engineering:**
   - Formulate composite indicators: `total_rooms`, `amenity_score`, `distance_score`, `property_age_group`, and `floor_ratio`.
   - Prevent data leakage by encapsulating all scaling and one-hot encoding within a strict Scikit-Learn `ColumnTransformer` pipeline.

4. **Multi-Model Machine Learning Benchmark:**
   - Train and benchmark five distinct machine learning algorithms:
     - Linear Regression (Baseline)
     - Decision Tree Regressor
     - Random Forest Regressor (Bagging Ensemble)
     - Gradient Boosting Regressor (Sequential Boosting)
     - XGBoost Regressor (Extreme Gradient Boosting)
   - Perform hyperparameter optimization using `RandomizedSearchCV` on top-performing architectures.

5. **Empirical Evaluation & Model Persistence:**
   - Evaluate all models across $MAE, MSE, RMSE, R^2,$ and $MAPE$.
   - Select the optimal model dynamically and persist artifacts via `Joblib`.

6. **Full-Stack REST Architecture:**
   - Build a production-grade FastAPI backend with Pydantic validation and SQLite audit logging.
   - Construct a modern, responsive React (Vite + Recharts) frontend providing property estimation, dataset analytics, model comparisons, and prediction history.
