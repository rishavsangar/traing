# Chapter 4: Literature Review

## 4.1 Evolution of Real Estate Valuation Methodologies

### 4.1.1 Hedonic Pricing Models (HPM)
Originating from the seminal economic work of Rosen (1974), Hedonic Pricing Theory asserts that a heterogeneous good (such as a house) is valued as an aggregation of its constituent characteristics (e.g., floor area, number of rooms, location, neighborhood amenities). Traditional Hedonic models deployed Ordinary Least Squares (OLS) Multiple Linear Regression:

$$P = \beta_0 + \sum_{j=1}^{k} \beta_j X_j + \epsilon$$

While interpretable, empirical literature (Bourassa et al., 2007; Pagourtzi et al., 2003) emphasizes that linear Hedonic models fail in real estate due to high multicollinearity, spatial autocorrelation, and complex non-linear attribute interactions.

### 4.1.2 Decision Trees and Bagging Ensembles
To overcome non-linearities, non-parametric tree methods (Breiman, 1984, 2001) were introduced to property valuation. Random Forests aggregate hundreds of de-correlated decision trees trained on bootstrap samples of the data ($X^{(b)}$), choosing split candidates from random feature subsets. Random Forests drastically reduce the variance associated with individual decision trees without inflating bias.

### 4.1.3 Gradient Boosting Machines & XGBoost
Gradient Boosting (Friedman, 2001) iteratively trains weak base learners $h_m(x)$ to predict the pseudo-residuals of the previous ensemble stage:

$$F_m(x) = F_{m-1}(x) + \gamma_m h_m(x)$$

Chen & Guestrin (2016) introduced **XGBoost (Extreme Gradient Boosting)**, which optimizes a regularized objective function combining convex loss with tree complexity penalties:

$$\mathcal{L}^{(t)} = \sum_{i=1}^{n} l\left(y_i, \hat{y}_i^{(t-1)} + f_t(x_i)\right) + \Omega(f_t)$$

where $\Omega(f) = \gamma T + \frac{1}{2}\lambda \sum_{j=1}^T w_j^2$. XGBoost incorporates second-order Taylor expansions of the loss function, sparsity awareness, and cache-aware memory access, consistently outperforming standard linear models in real estate regression tasks.

## 4.2 Synthesis and Research Gap

While academic literature has benchmarked regression algorithms on standard Western datasets (e.g., Boston Housing, Ames Housing, California Housing), relatively few end-to-end architectures bridge realistic Indian multi-tier housing dynamics with modern asynchronous REST APIs and Single Page Applications. This project addresses that gap by delivering an end-to-end deployed system.
