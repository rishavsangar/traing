# Chapter 9: Machine Learning Algorithms & Mathematical Formulations

## 9.1 Overview of Evaluated Algorithms

To determine the most accurate valuation engine, five regression models representing different algorithmic families were systematically trained and compared.

---

### 1. Ordinary Least Squares (OLS) Linear Regression

**Purpose:** Baseline benchmark.  
**Hypothesis:** $y = \mathbf{w}^T \mathbf{x} + b$  
**Cost Function:**
$$\mathcal{J}(\mathbf{w}, b) = \frac{1}{2N} \sum_{i=1}^N \left( (\mathbf{w}^T \mathbf{x}_i + b) - y_i \right)^2$$

**Strengths:** High interpretability, analytical closed-form solution via Normal Equation $(\mathbf{X}^T \mathbf{X})^{-1}\mathbf{X}^T \mathbf{y}$.  
**Limitations:** Underfits non-linear interactions (e.g., location multiplier $\times$ area scaling).

---

### 2. Decision Tree Regressor (CART)

**Purpose:** Capture non-linear feature interactions and threshold splits.  
**Splitting Criterion:** Minimizing Mean Squared Error across binary partitions:
$$\text{Cost}(S, j, t) = \frac{|S_L|}{|S|} \text{MSE}(S_L) + \frac{|S_R|}{|S|} \text{MSE}(S_R)$$
where $\text{MSE}(S) = \frac{1}{|S|} \sum_{i \in S} (y_i - \bar{y}_S)^2$.

**Strengths:** Completely non-parametric, models non-linear decision boundaries.  
**Limitations:** Prone to high variance and overfitting on continuous targets.

---

### 3. Random Forest Regressor (Ensemble Bagging)

**Purpose:** Robust ensemble reduction of decision tree variance.  
**Mechanism:** Constructs $B$ de-correlated trees via Bootstrap Aggregating (Bagging) and Random Feature Selection:
$$\hat{f}_{\text{RF}}(\mathbf{x}) = \frac{1}{B} \sum_{b=1}^B T_b(\mathbf{x})$$

**Strengths:** Exceptional generalization, immune to individual tree variance, outputs Gini/MDI feature importances.

---

### 4. Gradient Boosting Regressor (GBM)

**Purpose:** Sequential gradient descent in function space.  
**Mechanism:** Iteratively fits base regressors to negative gradients (pseudo-residuals):
$$r_{im} = -\left[ \frac{\partial \mathcal{L}(y_i, F(\mathbf{x}_i))}{\partial F(\mathbf{x}_i)} \right]_{F=F_{m-1}}$$
$$F_m(\mathbf{x}) = F_{m-1}(\mathbf{x}) + \eta \sum_j \gamma_{jm} \mathbb{I}(\mathbf{x} \in R_{jm})$$
where $\eta \in (0, 1]$ represents the shrinkage learning rate.

---

### 5. XGBoost Regressor (Extreme Gradient Boosting)

**Purpose:** State-of-the-art scalable gradient boosting with tree regularization.  
**Objective Function:**
$$\text{Obj}^{(t)} = \sum_{i=1}^n \left[ g_i f_t(\mathbf{x}_i) + \frac{1}{2} h_i f_t^2(\mathbf{x}_i) \right] + \gamma T + \frac{1}{2} \lambda \sum_{j=1}^T w_j^2$$
where $g_i = \partial_{\hat{y}^{(t-1)}} \mathcal{L}(y_i, \hat{y}^{(t-1)})$ and $h_i = \partial^2_{\hat{y}^{(t-1)}} \mathcal{L}(y_i, \hat{y}^{(t-1)})$.

**Strengths:** Second-order Taylor approximation, exact and approximate split finding, column subsampling, L1/L2 leaf weight regularization.
