# Abstract

**Project Title:** House Price Prediction Using Machine Learning  
**Domain:** Data Science / Machine Learning / PropTech  
**Author:** Summer Training Project Cohort  

---

### Executive Summary

In contemporary real estate markets, determining an accurate valuation for residential property represents a complex multi-criteria decision challenge. Traditional human appraisal methodologies frequently suffer from subjective bias, geographical opacity, and an inability to account for multi-variable non-linear interactions across urban infrastructure, spatial coordinates, and property amenities.

This Summer Training Data Science project develops a complete, production-grade **Machine Learning Housing Valuation System** calibrated to the Indian real estate market. The project encompasses the entire Data Science lifecycle:

1. **Synthetic & Realistic Dataset Engineering**: Generating over 12,000+ realistic property records across 13 major Indian metropolitan markets (Mumbai, Delhi, Bangalore, Hyderabad, Chandigarh, Mohali, Jalandhar, Ludhiana, Amritsar, Pune, Jaipur, Noida, Gurgaon).
2. **Robust Data Preprocessing**: Removing duplicate instances, handling invalid data boundaries, imputing missing values with median/mode strategies, and filtering extreme outliers using Interquartile Range (IQR) methods without introducing data leakage.
3. **Domain Feature Engineering**: Synthesizing derived metrics including composite amenity indices, inverse distance connectivity scores, age group categorizations, and floor ratios.
4. **Machine Learning Benchmarking & Tuning**: Comparative training across five distinct regression paradigms—**Linear Regression (Baseline)**, **Decision Tree Regressor**, **Random Forest Regressor**, **Gradient Boosting Regressor**, and **XGBoost Regressor**—followed by `RandomizedSearchCV` hyperparameter optimization.
5. **Model Evaluation & Persistence**: Benchmarking models using $MAE$, $MSE$, $RMSE$, $R^2$, and $MAPE$, with the top performer achieving $R^2 > 0.90$, serialized into production artifacts using `Joblib`.
6. **Full-Stack Deployment**: Exposing inference endpoints through a high-performance **FastAPI** REST backend backed by SQLite persistence, integrated with an interactive **React (Vite + Recharts)** Single Page Application.

The final system offers an intuitive, responsive interface returning instant property valuations along with statistical confidence ranges, dataset visual analytics, model leaderboards, and historical audit logs suitable for commercial PropTech evaluation and academic demonstration.
